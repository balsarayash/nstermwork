import java.util.*;

public class q1_ceasarcipher
{
	public static void main(String args[])
	{
		String s;
		Scanner sc=new Scanner(System.in);
		System.out.print("\nEnter Text You want to Encrypt: ");
		s=sc.nextLine();
		
		System.out.println("Ciphered Text: " + encrypt(s));
		System.out.println("Decrypted Text: " + decrypt(encrypt(s)));
	}
	
	public static String encrypt(String s)
	{
		StringBuilder sb=new StringBuilder();
		char c;
		for(int i=0; i<s.length(); i++)
		{
			if((s.charAt(i)>='a' && s.charAt(i)<='z') || (s.charAt(i)>='A' && s.charAt(i)<='Z'))
			{
				if(s.charAt(i)<='c' && s.charAt(i)>=97)
				{
					c=(char)(s.charAt(i)+23);
					sb.append(c);
					continue;					
				}
				else if(s.charAt(i)<='C')
				{
					c=(char)(s.charAt(i)+23);
					sb.append(c);
					continue;
				}
				c=(char)(s.charAt(i)-3);
				sb.append(c);
				continue;
			}
			else if(s.charAt(i)>='0' && s.charAt(i)<='9')
			{
				if(s.charAt(i)<='2')
				{
					c=(char)(s.charAt(i)+7);
					sb.append(c);
					continue;					
				}
				c=(char)(s.charAt(i)-3);
				sb.append(c);
				continue;
			}
			sb.append(s.charAt(i));
		}
		return sb.toString();
	}
	
	public static String decrypt(String s)
	{
		StringBuilder sb=new StringBuilder();
		char c;
		for(int i=0; i<s.length(); i++)
		{
			if((s.charAt(i)>='a' && s.charAt(i)<='z') || (s.charAt(i)>='A' && s.charAt(i)<='Z'))
			{
				if(s.charAt(i)>='x')
				{
					c=(char)(s.charAt(i)-23);
					sb.append(c);
					continue;					
				}
				else if(s.charAt(i)>='X' && s.charAt(i)<=90)
				{
					c=(char)(s.charAt(i)-23);
					sb.append(c);
					continue;
				}
				c=(char)(s.charAt(i)+3);
				sb.append(c);
				continue;
			}
			else if(s.charAt(i)>='0' && s.charAt(i)<='9')
			{
				if(s.charAt(i)>='7')
				{
					c=(char)(s.charAt(i)-7);
					sb.append(c);
					continue;					
				}
				c=(char)(s.charAt(i)+3);
				sb.append(c);
				continue;
			}
			sb.append(s.charAt(i));
		}
		return sb.toString();
	}
}