import bsr.*;
public class sender
{
 public static void main(String args[])throws Exception
 {
  
  String myString="BipinRupadiya";
  
  PBOX obj =new PBOX();
  
  String encryptedString=obj.doEncryption(myString);
  System.out.println("\nEncryted String : "+encryptedString);
  MySocket m = new MySocket();
  m.sendFrame(encryptedString);
 }

}